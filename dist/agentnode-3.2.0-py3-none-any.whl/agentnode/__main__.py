import argparse, os
from .core.config import init_config

def main():
    ap=argparse.ArgumentParser('agentnode'); sp=ap.add_subparsers(dest='cmd')
    run=sp.add_parser('serve'); run.add_argument('--config',default=os.getenv('AGENTNODE_CONFIG','config.yaml')); run.add_argument('--host'); run.add_argument('--port',type=int)
    stdio=sp.add_parser('mcp-stdio'); stdio.add_argument('--config',default=os.getenv('AGENTNODE_CONFIG','config.yaml'))
    init=sp.add_parser('init'); init.add_argument('--config',default='config.yaml')
    desk=sp.add_parser('desktop-worker'); desk.add_argument('--config',default='config.yaml')
    args=ap.parse_args()
    if args.cmd=='init':
        _,tokens=init_config(args.config); print('TOKENS (shown once):'); [print(f'{k}: {v}') for k,v in tokens.items()]; return
    if args.cmd=='desktop-worker':
        from .desktop.worker import main as dm; import sys; sys.argv=[sys.argv[0],'--config',args.config]; dm(); return
    if args.cmd=='mcp-stdio':
        os.environ['AGENTNODE_CONFIG']=args.config
        os.environ['AGENTNODE_MCP_TRANSPORT']='stdio'
        from .app import create_app
        app=create_app(args.config); mcp=app.state.ctx.get('mcp')
        if mcp is None: raise SystemExit("MCP SDK is not installed. Install: pip install 'agentnode[mcp]'")
        mcp.run(transport='stdio'); return
    from .core.config import load_config
    cfg=load_config(args.config if hasattr(args,'config') else 'config.yaml'); os.environ['AGENTNODE_CONFIG']=args.config if hasattr(args,'config') else 'config.yaml'
    import uvicorn
    uvicorn.run('agentnode.app:create_app',factory=True,host=getattr(args,'host',None) or cfg.host,port=getattr(args,'port',None) or cfg.port)
if __name__=='__main__':main()
