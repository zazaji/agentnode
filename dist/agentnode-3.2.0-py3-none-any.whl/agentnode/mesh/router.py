from __future__ import annotations
import os,uuid,httpx
from ..models import DelegateRequest,Principal
from ..core.auth import require
class MeshRouter:
    def __init__(self,cfg): self.cfg=cfg
    def peers(self): return {k:{"url":v.get('url'),"token_configured":bool(v.get('token') or v.get('token_env'))} for k,v in self.cfg.mesh.peers.items()}
    async def delegate(self,p:Principal,req:DelegateRequest):
        require(p,'mesh.delegate'); nid=self.cfg.mesh.node_id
        if nid in req.hops: raise ValueError('mesh loop detected')
        hops=[*req.hops,nid]
        if len(hops)>self.cfg.mesh.max_hops: raise ValueError('max hops exceeded')
        peer=self.cfg.mesh.peers.get(req.peer)
        if not peer: raise KeyError(f'unknown peer: {req.peer}')
        token=peer.get('token') or os.getenv(peer.get('token_env',''))
        if not token: raise RuntimeError('peer token not configured')
        trace=req.trace_id or uuid.uuid4().hex
        endpoint='/api/v1/shell' if req.action=='shell' else '/api/v1/agent'
        payload=dict(req.payload); payload['trace_id']=trace; payload['hops']=hops
        async with httpx.AsyncClient(timeout=60) as c:
            r=await c.post(peer['url'].rstrip('/')+endpoint,json=payload,headers={'Authorization':f'Bearer {token}'})
            r.raise_for_status(); return {'trace_id':trace,'peer':req.peer,'response':r.json()}
