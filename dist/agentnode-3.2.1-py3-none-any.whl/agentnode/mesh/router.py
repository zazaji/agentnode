from __future__ import annotations
import asyncio, os, uuid, httpx
from ..models import DelegateRequest, CoordinateRequest, Principal
from ..core.auth import require
class MeshRouter:
    def __init__(self,cfg): self.cfg=cfg
    def peers(self): return {k:{"url":v.get('url'),"token_configured":bool(v.get('token') or v.get('token_env'))} for k,v in self.cfg.mesh.peers.items()}
    def _check_trace(self,hops:list[str]):
        nid=self.cfg.mesh.node_id
        if nid in hops: raise ValueError('mesh loop detected')
        hops=[*hops,nid]
        if len(hops)>self.cfg.mesh.max_hops: raise ValueError('max hops exceeded')
        return hops
    async def _invoke(self,peer_name:str,action:str,payload:dict,trace_id:str,hops:list[str],timeout_s:float=60):
        peer=self.cfg.mesh.peers.get(peer_name)
        if not peer: raise KeyError(f'unknown peer: {peer_name}')
        token=peer.get('token') or os.getenv(peer.get('token_env',''))
        if not token: raise RuntimeError('peer token not configured')
        endpoint='/api/v1/shell' if action=='shell' else '/api/v1/agent'
        body=dict(payload); body['trace_id']=trace_id; body['hops']=hops
        async with httpx.AsyncClient(timeout=timeout_s) as c:
            r=await c.post(peer['url'].rstrip('/')+endpoint,json=body,headers={'Authorization':f'Bearer {token}'})
            r.raise_for_status(); return r.json()
    async def delegate(self,p:Principal,req:DelegateRequest):
        require(p,'mesh.delegate'); hops=self._check_trace(req.hops)
        trace=req.trace_id or uuid.uuid4().hex
        resp=await self._invoke(req.peer,req.action,req.payload,trace,hops)
        return {'trace_id':trace,'peer':req.peer,'response':resp}
    async def coordinate(self,p:Principal,req:CoordinateRequest):
        require(p,'mesh.delegate'); hops=self._check_trace(req.hops)
        trace=req.trace_id or uuid.uuid4().hex
        unknown=[k for k in (req.peers or []) if k not in self.cfg.mesh.peers]
        targets=[n for n in self.cfg.mesh.peers if n!=self.cfg.mesh.node_id and (req.peers is None or n in req.peers)]
        results={}
        async def one(name:str):
            try:
                resp=await asyncio.wait_for(self._invoke(name,req.task.action,dict(req.task.payload),trace,hops,req.timeout_s),timeout=req.timeout_s)
                results[name]={'ok':True,'trace_id':trace,'response':resp}
            except asyncio.TimeoutError:
                results[name]={'ok':False,'trace_id':trace,'error':'timeout'}
            except Exception as e:
                results[name]={'ok':False,'trace_id':trace,'error':str(e)}
        tasks=[asyncio.create_task(one(n)) for n in targets]
        if req.parallel: await asyncio.gather(*tasks)
        else:
            for t in tasks: await t
        return {'trace_id':trace,'coordinator':self.cfg.mesh.node_id,'parallel':req.parallel,
                'targets':targets,'unknown':unknown,'results':results}
